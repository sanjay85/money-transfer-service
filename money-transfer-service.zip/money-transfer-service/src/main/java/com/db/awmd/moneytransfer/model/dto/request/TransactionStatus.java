package com.db.awmd.moneytransfer.model.dto.request;

public enum TransactionStatus {
	PENDING, PROCESSING, SUCCESS, FAILED
}
